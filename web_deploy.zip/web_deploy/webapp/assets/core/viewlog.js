var vl = {};

vl.selectview = ko.observable('webapp')
vl.selectviewList = ko.observable([{value:"webapp",text:"Webapp"},{value:"consoleapps",text:"Consoleapps"}])
vl.logdate = ko.observable(kendo.toString(new Date(), "yyyy-MM-dd HH:mm:ss"))

vl.getselectView = function(){
    var payload = {
        Mode : vl.selectview(),
    }
    ajaxPost("/configuration/checklog", payload, function(res){
        $("#viewlogtext").val(res.data);
    })
}

vl.downloadFileLog = function(){
    var payload = {
        Datestring : kendo.toString(new Date(vl.logdate()), "yyyy-MM-dd"),
    }
    ajaxPost("/configuration/downloadfilelog", payload, function(res){
        window.location.href = res.data.filepath
    })
}

$(function(){
	$("#logdatepicker1").kendoDatePicker({
        format: "yyyy-MM-dd",
        value: new Date()
    })
})