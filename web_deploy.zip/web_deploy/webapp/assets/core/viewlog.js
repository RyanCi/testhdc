var vl = {};

vl.selectview = ko.observable('webapp')
vl.selectviewList = ko.observable([{value:"webapp",text:"Webapp"},{value:"consoleapps",text:"Consoleapps"}])

vl.getselectView = function(){
    var payload = {
        Mode : vl.selectview(),
    }
    ajaxPost("/configuration/checklog", payload, function(res){
        $("#viewlogtext").val(res.data);
    })
}

$(function(){
})